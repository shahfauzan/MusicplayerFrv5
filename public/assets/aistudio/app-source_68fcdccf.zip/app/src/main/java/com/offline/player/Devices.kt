package com.offline.player

import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** kind: 0 earbuds, 1 headphones, 2 speaker */
data class AudioOut(val kind: Int, val name: String, val at: Long = System.currentTimeMillis())

private fun looksLikeSpeaker(n: String) = Regex("speaker|soundbar|boom", RegexOption.IGNORE_CASE).containsMatchIn(n)

private fun describe(d: AudioDeviceInfo): AudioOut? {
    val n = d.productName?.toString()?.trim().orEmpty()
    return when (d.type) {
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLE_HEADSET ->
            AudioOut(if (looksLikeSpeaker(n)) 2 else 0, n.ifBlank { "Bluetooth audio" })
        AudioDeviceInfo.TYPE_BLE_SPEAKER -> AudioOut(2, n.ifBlank { "Bluetooth speaker" })
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_USB_HEADSET ->
            AudioOut(1, "Headphones")
        AudioDeviceInfo.TYPE_LINE_ANALOG, AudioDeviceInfo.TYPE_AUX_LINE -> AudioOut(2, "External speaker")
        else -> null
    }
}

/** Reports audio outputs that connect while the app is open. Devices already connected at start are ignored. */
@Composable
fun AudioOutputWatcher(onConnected: (AudioOut) -> Unit) {
    val ctx = LocalContext.current
    val cb = rememberUpdatedState(onConnected)
    DisposableEffect(Unit) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val known = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).map { it.id }.toMutableSet()
        val callback = object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>) {
                for (d in added) {
                    if (d.isSink && known.add(d.id)) {
                        val out = describe(d)
                        if (out != null) { cb.value(out); return }
                    }
                }
            }
            override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>) {
                removed.forEach { known.remove(it.id) }
            }
        }
        am.registerAudioDeviceCallback(callback, Handler(Looper.getMainLooper()))
        onDispose { am.unregisterAudioDeviceCallback(callback) }
    }
}

@Composable
fun DeviceCard(d: AudioOut, onDismiss: () -> Unit) {
    val u = LocalUi.current
    val label = when (d.kind) { 0 -> "Earbuds connected"; 1 -> "Headphones connected"; else -> "Speaker connected" }
    Column(
        Modifier.padding(horizontal = 20.dp).fillMaxWidth().widthIn(max = 420.dp)
            .glass(32.dp).clickable(onClickLabel = "Dismiss") { onDismiss() }.padding(20.dp)
            .semantics { liveRegion = LiveRegionMode.Polite; contentDescription = "$label: ${d.name}" },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        DeviceArt(d.kind, u.accent, Modifier.fillMaxWidth().height(110.dp))
        Spacer(Modifier.height(8.dp))
        Text(label, fontSize = 13.sp, color = u.accentText, fontWeight = FontWeight.SemiBold)
        Text(d.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = u.text, textAlign = TextAlign.Center, maxLines = 1)
        Spacer(Modifier.height(2.dp))
        Text("Tap to dismiss", fontSize = 12.sp, color = u.dim)
    }
}

@Composable
fun DeviceArt(kind: Int, accent: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val c = center
        val g = size.height * .62f
        drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = .40f), Color.Transparent), center = c, radius = g * 1.5f), radius = g * 1.5f, center = c)
        val body = Brush.verticalGradient(listOf(Color.White, Color(0xFFCFD3E0)))
        val dark = Color(0xFF23232E)
        when (kind) {
            0 -> for (s in listOf(-1f, 1f)) {
                val x = c.x + s * size.height * .42f
                rotate(s * 16f, Offset(x, c.y)) {
                    drawRoundRect(body, Offset(x - 7.dp.toPx(), c.y - 6.dp.toPx()), Size(14.dp.toPx(), 50.dp.toPx()), CornerRadius(7.dp.toPx()))
                    drawCircle(body, 21.dp.toPx(), Offset(x, c.y - 14.dp.toPx()))
                    drawCircle(dark, 7.dp.toPx(), Offset(x - s * 6.dp.toPx(), c.y - 14.dp.toPx()))
                }
            }
            1 -> {
                val r = size.height * .36f
                val cy = c.y + 6.dp.toPx()
                drawArc(Color.White, 180f, 180f, false, Offset(c.x - r, cy - r), Size(r * 2, r * 2), style = Stroke(9.dp.toPx(), cap = StrokeCap.Round))
                for (s in listOf(-1f, 1f)) {
                    drawRoundRect(body, Offset(c.x + s * r - 12.dp.toPx(), cy - 4.dp.toPx()), Size(24.dp.toPx(), 40.dp.toPx()), CornerRadius(12.dp.toPx()))
                }
            }
            else -> {
                val w = size.height * .62f
                val h = size.height * .86f
                drawRoundRect(body, Offset(c.x - w / 2, c.y - h / 2), Size(w, h), CornerRadius(16.dp.toPx()))
                drawCircle(dark, w * .30f, Offset(c.x, c.y + h * .14f))
                drawCircle(dark, w * .12f, Offset(c.x, c.y - h * .27f))
            }
        }
    }
}
